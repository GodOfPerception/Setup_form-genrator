#!/bin/bash

/usr/bin/python3 -m pip install requests
/usr/bin/python3 -m pip install svgwrite
/usr/bin/python3 -m pip install pillow
/usr/bin/python3 -m pip install json
/usr/bin/python3 -m pip install os